import os, time
os.system("cls")

if os.path.isdir("./users"):
    print("Users directory exists")

else:
    print("Users directory does not exist")
    print("Creating users directory...")
    os.mkdir("./users")
    print("")
    print("Created users directory")

if os.path.isfile("session.txt"):
    os.remove("session.txt")


print("")
print("System [OK]")
os.system("cls")


def logout():
    
    os.remove("session.txt")
    time.sleep(2)

    os.system("cls")
    dash()


def remove():

    os.system("cls")
    usr = input("Username? ")

    if usr == "":
        print("Username is empty")
        input("Press ENTER to continue...")
        login()

    else:

        path = "./users/" + str(usr) + ".txt"
        if os.path.isfile(path):
            password = input("Password (cleartext)? ")

            if password == "":
                print("Password is empty")
                input("Press ENTER to continue...")

            else:
                p = open(str(path), "r").read()

                if password == str(p):

                    os.remove(str(path))

                    time.sleep(2)
                    os.remove("session.txt")
                    
                    print("---Removed user:", str(usr),"---")
                    input("Press ENTER to continue...")
                    os.system("cls")
                    dash()
                else:
                    print("Invalid password")
                    input("Press ENTER to continue...")
                    login()
                
                

        else:
            print("User does not exist")
            input("Press ENTER to continue...")
            login()






def login():

    os.system("cls")
    usr = input("Username? ")

    if usr == "":
        print("Username is empty")
        input("Press ENTER to continue...")
        login()

    else:

        path = "./users/" + str(usr) + ".txt"
        if os.path.isfile(path):
            password = input("Password (cleartext)? ")

            if password == "":
                print("Password is empty")
                input("Press ENTER to continue...")

            else:
                p = open(str(path), "r").read()

                if password == str(p):

                    sessionFile = open("session.txt", "x")
                    sessionFile.write(str(usr))
                    sessionFile.close()
                    
                    os.system("cls")
                    dash()
                else:
                    print("Invalid password")
                    input("Press ENTER to continue...")
                    login()
                
                

        else:
            print("User does not exist")
            input("Press ENTER to continue...")
            login()



def register():
    os.system("cls")
    u = input("Username? ")

    if u == "":
        print("Try again")
        print("")
        register()

    else:

        filePath = "./users/" + str(u) + ".txt"
        if os.path.isfile(filePath):
            print("User already exists")
            input("Press ENTER to try again...")
            print("")
            register()

        else:
            p = input("Password (cleartext)? ")

            if p == "":
                print("Try again")
                print("")
                register()

            else:
                    
                print("Creating user",str(u),"...")

                path = "./users/" + str(u) + ".txt"
                newFile = open(path, "w")
                newFile.write(str(p))
                newFile.close()
                
                print("User creation [OK]")
                os.system("cls")
                dash()



def dash():


    if os.path.isfile("session.txt"):

        sessionFile = open("session.txt", "r")
        line = sessionFile.readline()
        sessionFile.close()
        
        
        print("Dashboard --- Logged in as:",str(line))
        print("")

    else:
        print("Dashboard")
        print("")

    
    f = open("./cList.txt", "r").read().split("\n") #read from cList, remove newline chars
    for line in f:
        print(line)
    
    print("")
    i = input(">")


    if i == "":
        print("")
        dash()

    elif i == "register":
        register()

    elif i == "login":
        login()

    elif i == "delete":
        remove()

    elif i == "logout":
        logout()

    else:
        print("")
        dash()

#init
dash()

