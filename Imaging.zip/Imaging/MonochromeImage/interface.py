#import tkinter.ttk
from tkinter import *
from tkinter import filedialog
from tkinter import ttk
import img_gen

fname = ""

def openFile():
    file = filedialog.askopenfile(mode="r", title="Choose an image file")
    if file != None:
        newFilename = ""

        r = False
        override = False
        
        for char in str(file):
            if char == "'" and r == False:
                r = True

            elif char != "'" and r == True and override == False:
                newFilename += char

            elif char == "'" and r == True:
                r = False
                override = True

        global fname
        fname = newFilename
        print(f"Filename (Tkinter): {fname}")
        
      
    else:
        pass


window = Tk()
window.title("Monochromatic Image Converter (Python)")
window.config(background="#FFF")
window.geometry("640x480")
window.anchor("center")

tx1 = Label (window, text="Monochromatic Image Converter", bg="#FFF", fg="#000", font="none 12 normal")
tx1.pack(side="top", pady="25")

tx3 = Label (window, text="Source Image:", bg="#FFF", fg="#000", font="none 12 bold", pady=0)
tx3.pack(side="top", pady="25")

openBtn = Button(text="Browse...", width="20", pady="2", command=lambda: openFile())
openBtn.pack(side="top", pady="10")

#sentVars = img_gen.run(100, 100, "(0, 50, 255)")

sendBtn = Button(text="Convert", width="20", pady="2", command=lambda: img_gen.run(fname))
sendBtn.pack(side="top", pady="10")

window.mainloop()
