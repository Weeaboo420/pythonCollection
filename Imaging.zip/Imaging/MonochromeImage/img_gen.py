from PIL import Image
import os, random as ran, os


def generate(n, size_x, size_y):

    myImage = Image.new("RGB", (size_x, size_y), 0)
    myName = n + "_mono_"
    i = 0
    myName += str(i)
    
    #myName += str(ran.randrange(100000, 10000000, ran.randint(1, 10)))
    myName += ".jpg"

    resX, resY = myImage.size

    for y in range(resY):
        for x in range(resX):
            pass
            #s = x+y
            #myImage.putpixel((x, y), (ran.randrange(0, 255), ran.randrange(0, 255), ran.randrange(0, 255)))

    while os.path.isfile(myName):
        myName = "image_"
        i += 1
        myName += str(i)
        myName += ".jpg"
        
    myImage.save(myName, "jpeg")
    print(f"Saved image as {myName} ({resX}x{resY})")


#while True:
def run(fname):
    if len(fname) > 0:
        print(f"(IMG_GEN) Filename: {fname}")
        temp = Image.open(fname)
        name, width, height = temp.filename, temp.width, temp.height
        temp.close()
        #print(name, width, height)
        generate(name, width, height)

    elif len(fname) == 0:
        print("ERROR: Filename must be longer than 0 characters!")


