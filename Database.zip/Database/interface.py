import mainframe, os

def clear():
    if os.name == "nt":
        os.system("cls")
    else:
        os.system("clear")

run = True
try:
    n = mainframe.get("name")
    print(f"Hello! My name is {n}")

except:
    pass

while run:
    i = input(">")

    if len(i) == 0:
        pass
    else:
        if i == "clear" or i == "cls":
            clear()

        else:
            mainframe.interpret(i)
    
