import os
###basic backend functions###



#split the proprety name from the property value when reading a line
def divide(i):

    gather = False
    p = ""
    val = ""
    
    for char in i:
        if gather == True and char != "\n" and char != " ":
            val+=char
        
        if char == " " and gather == False:
            gather = True

        elif gather == False and char != " ":
            p+=char
            
    return p, val

#learn something new, adds a new property and a value associated with it
def learn(propertyName, value):

    count = len(open("database.data").readlines())
    f = open("database.data", mode="a+")

    #if count == 0:
    #    f.write(f"{propertyName} {value}")

    #else:
    f.write(f"\n{propertyName} {value}")
    f.close()

#return the value of a property, requires divide()
def get(propertyName):
    f = open("database.data", mode="r")
    r = ""

    f.seek(0)
    look = True
    linePos = 0
    lineCount = len(open("database.data").readlines())
    
    while look == True:
        line = f.readline()
        prop, val = divide(line)
        
        if prop == propertyName:
            #property found, now find the value
            return val
            look = False            
            
        else:
            if linePos == lineCount:
                look = False
                raise ValueError("Could not find the specified property")
                
            else:
                pass

        linePos += 1

#check for database
db = os.path.isfile("database.data")

if db:
    pass

else:
    #print("[ERR] No database found")
    #print("Creating database.data...")
    f = open("database.data", mode="x")
    f.close()

    learn("name", "Meta")


#interpret the user's input
def interpret(info):
    
    #create a list to store args
    arguments = []
    currentWord = ""
    info += " "
    
    for char in info:
        if char == " ":
            arguments.append(currentWord)
            currentWord = ""
        else:
            currentWord += char


    if arguments[0] == "get":
        if len(arguments) == 2:
            try:
                print(f"{get(arguments[1])}")
            except:
                print("I am sorry, but there is no property by that name.")
            
        elif len(arguments) < 2:
            print("I am sorry, you need to specify a property name.")

        elif len(arguments) > 2:
            print("You have provided too many arguments.")


    elif arguments[0] == "learn":
        if len(arguments) == 3:
            learn(arguments[1], arguments[2])

        elif len(arguments) < 3:
            print("You need to provide more information than that. Syntax: learn propertyName value")

        elif len(arguments) > 3:
            print("You have provided too many arguments.")
